console.log("Function.js")


function convertTemperature(celsius){
    console.log(celsius*9/5 +32);
    return celsius * 9/5 + 32;
}

convertTemperature(10); //50
convertTemperature(20); //68

let total = 0;
let tempName = prompt ("Enter Temperature here");

function addTemperatureinCelsius(){
    let tempName= prompt("Temperature to Celsius");
}